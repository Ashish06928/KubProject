﻿using AspnetRun.Core.Entities.Base;

namespace AspnetRun.Core.Entities
{
    public class Tag : Entity
    {
        public string Name { get; set; }
    }
}
